<?php $__env->startSection('content'); ?>
    <div class="bg-gray-800 p-4 rounded-lg">
        <h2 class="text-2xl font-bold mb-4">Sales Report</h2>

        <form action="<?php echo e(route('sales.report')); ?>" method="GET" class="mb-4 flex items-center justify-between">
            <div class="flex items-center">
                <label for="month" class="text-white mr-2">Select Month:</label>
                <input type="month" id="month" name="month" class="bg-gray-700 text-white rounded p-2"
                    value="<?php echo e(request('month') ?? \Carbon\Carbon::now()->format('Y-m')); ?>">
                <button type="submit" class="bg-blue-500 text-white rounded px-4 py-2 ml-2">Generate Report</button>
            </div>
            <?php if(session('status')): ?>
                <div class="bg-green-500 text-white p-2 rounded">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </form>

        <?php if(isset($sales)): ?>
            <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                <table class="w-full text-sm text-left rtl:text-right text-gray-400 text-center">
                    <thead class="text-xs uppercase bg-gray-700 text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3 w-5">No.</th>
                            <th scope="col" class="px-6 py-3">Order Serial Number</th>
                            <th scope="col" class="px-6 py-3">Game ID</th>
                            <th scope="col" class="px-6 py-3">Server Number</th>
                            <th scope="col" class="px-6 py-3">Product</th>
                            <th scope="col" class="px-6 py-3">Product Code</th>
                            <th scope="col" class="px-6 py-3">Category</th>
                            <th scope="col" class="px-6 py-3">Gross Price</th>
                            <th scope="col" class="px-6 py-3">Status</th>
                            <th scope="col" class="px-6 py-3">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b bg-gray-800 border-gray-700">
                                <td class="px-6 py-2"><?php echo e(++$i); ?></td>
                                <td class="px-6 py-2"><?php echo e($sale->order_serial_number); ?></td>
                                <td class="px-6 py-2"><?php echo e($sale->game_id); ?></td>
                                <td class="px-6 py-2"><?php echo e($sale->server_num); ?></td>
                                <td class="px-6 py-2"><?php echo e($sale->item); ?></td>
                                <td class="px-6 py-2"><?php echo e($sale->product_serial_number); ?></td>
                                <td class="px-6 py-2"><?php echo e($sale->name); ?></td>
                                <td class="px-6 py-2">Rp. <?php echo number_format($sale->gross_price,0,',','.'); ?></td>
                                <td class="px-6 py-2"><?php echo e($sale->status); ?></td>
                                <td class="px-6 py-2"><?php echo e($sale->created_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4 flex justify-end items-center">
                <!-- Pagination links if necessary -->
                <?php echo e($sales->links()); ?>

            </div>
            <div class="mt-4 bg-gray-700 p-4 rounded-lg">
                <h3 class="text-xl font-bold text-white">Summary</h3>
                <p class="text-white">Total Sales: Rp. <?php echo number_format($totalSales,0,',','.'); ?></p>
                <p class="text-white">Total Quantity Sold: <?php echo e($totalQuantity); ?></p>
            </div>
        <?php else: ?>
            <p class="text-white mt-4">No sales data available for the selected month.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\Laravel\wstore\resources\views/admin/report.blade.php ENDPATH**/ ?>